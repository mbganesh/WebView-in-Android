package com.netcom.cdata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import static com.netcom.cdata.R.string.table;

public class MainActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        webView = findViewById(R.id.webViewId);
        final String mimeType = "text/html";
        final String encoding = "UTF-8";
        String check = "<font size=\"20\">Text in bigger font size 20..</font><font size=\"10\"> Text in normal font size 10</font>";
        String table = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "<style>\n" +
                "table, th, td {\n" +
                "  border: 1px solid black;\n" +
                "  border-collapse: collapse;\n" +
                "}\n" +
                "th, td {\n" +
                "  padding: 5px;\n" +
                "  text-align: left;    \n" +
                "text-align: center;"+
                "}\n" +
                "</style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<center><h2>Science</h2></center>\n" +
                "<table style=\"width:100%\">\n" +
                "  <tr>\n" +
                "    <th  colspan=\"2\" style=\"background-color:LightGreen;\" >Physics</th>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>1</td>\n" +
                "    <td>Measurement</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>2</td>\n" +
                "    <td>Motion</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>3</td>\n" +
                "    <td>Fluids</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>4</td>\n" +
                "    <td>Electric charge and Electric Current</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>5</td>\n" +
                "    <td>Magnetism and Electromagnetism</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>6</td>\n" +
                "    <td>Light</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>7</td>\n" +
                "    <td>Heat</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>8</td>\n" +
                "    <td>Sound</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>9</td>\n" +
                "    <td>Universe</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>10</td>\n" +
                "    <td>Parts of Computer</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>11</td>\n" +
                "    <td>Computer-An Introduction</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <th colspan=\"2\" style=\"background-color:LightGreen;\">Chemistry</th>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>1</td>\n" +
                "    <td>Matter around us</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>2</td>\n" +
                "    <td>Atomic Structure</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>3</td>\n" +
                "    <td>Periodic Classification of Elements</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>4</td>\n" +
                "    <td>Chemical Bonding</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>5</td>\n" +
                "    <td>Acids, Bases and Salts</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>6</td>\n" +
                "    <td>Carbon and its Compounds</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>7</td>\n" +
                "    <td>Applied Chemistry</td>\n" +
                "  </tr>\n" +
                "    <tr>\n" +
                "    <th colspan=\"2\" style=\"background-color:LightGreen;\">Biology</th>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "    <td>1</td>\n" +
                "    <td>Animal Kingdom</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>2</td>\n" +
                "    <td>Organisation of Tissues</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>3</td>\n" +
                "    <td>Plant Physiology</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>4</td>\n" +
                "    <td>Organ System in Animals </td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>5</td>\n" +
                "    <td>Nutrition and Health</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>6</td>\n" +
                "    <td>World of Microbes</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>7</td>\n" +
                "    <td>Economic Biology</td>\n" +
                "  </tr>\n" +
                "  <tr>\n" +
                "  \t<td>8</td>\n" +
                "    <td>Environmental Science</td>\n" +
                "  </tr>\n" +
                "</table>\n" +
                "<img src=\"https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/img%2Fnamo.jpg?alt=media&token=897dd277-0194-40d4-bab0-0c84639479bc\" alt=\"Narendra Modi\">\n" +
                "</body>\n" +
                "</html>\n" +
                "<embed src=\"https://firebasestorage.googleapis.com/v0/b/exo-player-b8500.appspot.com/o/PDF%2Fsample_pdf.pdf?alt=media&token=806593dd-a34a-4e0b-8060-4895dd90add0\" alt=\"Sample PDF File\" />";

        webView.loadDataWithBaseURL(null , table , mimeType , encoding , null);
    }
}
